-- Torqz Garage | Torqz Mods
-- Vehicle Lua: measures driving while the player is in this car, reports running
-- totals to GameEngine Lua about once a second, and applies wear effects
-- (brakes, tire grip, engine power) when the garage asks for them.

local M = {}

local SAMPLE_EVERY = 0.05 -- seconds (20 Hz)
local REPORT_EVERY = 1.0  -- seconds

local token = tostring(os.time and os.time() or 0) .. ":" .. tostring(math.floor((os.clock and os.clock() or 0) * 1e6))
  .. ":" .. tostring({}):sub(8)
local totals = {dist = 0, drive = 0, tire = 0, brake = 0, engine = 0}
local model, hash, configName = nil, nil, nil
local lastX, lastY, lastZ, lastSpeed = nil, nil, nil, nil
local sampleTimer, reportTimer, identityTimer = 0, 0, 0
local wasSeated = false
local peakSpeed = 0

-- wear effects
local wanted = {brakes = 1, tires = 1, engine = 1}
local applied = {brakes = 1, tires = 1, engine = 1}
local engineFactorInUse = 1
local reapplyTimer = nil

local function num(value)
  if type(value) == "number" and value == value and value ~= math.huge and value ~= -math.huge then
    return value
  end
  return nil
end

local function clamp(x, a, b) if x < a then return a elseif x > b then return b end return x end

local function ev(name)
  if electrics and electrics.values then return electrics.values[name] end
  return nil
end

local function isSeated()
  return playerInfo ~= nil and playerInfo.anyPlayerSeated == true
end

-- Small stable hash so the same setup always gives the same fingerprint.
local function hashText(text)
  local h = 5381
  for i = 1, #text do h = (h * 33 + text:byte(i)) % 4294967296 end
  return string.format("%08x", h)
end

local function findParts()
  local candidates = {}
  if v and type(v.config) == "table" then
    candidates[#candidates + 1] = {parts = v.config.parts, name = v.config.partConfigFilename}
  end
  if partmgmt and type(partmgmt.getConfig) == "function" then
    local ok, cfg = pcall(partmgmt.getConfig)
    if ok and type(cfg) == "table" then candidates[#candidates + 1] = {parts = cfg.parts, name = cfg.partConfigFilename} end
  end
  if v and type(v.userPartConfig) == "table" then candidates[#candidates + 1] = {parts = v.userPartConfig} end
  for _, c in ipairs(candidates) do
    if type(c.parts) == "table" and next(c.parts) ~= nil then return c.parts, c.name end
  end
  return nil, candidates[1] and candidates[1].name
end

local function readIdentity()
  local dir = v and v.data and v.data.vehicleDirectory
  if type(dir) == "string" then
    model = dir:gsub("\\", "/"):gsub("/+$", ""):match("([^/]+)$")
  end
  local parts, name = findParts()
  configName = type(name) == "string" and name:gsub("\\", "/"):match("([^/]+)%.pc$") or configName
  if parts then
    local items = {}
    for slot, part in pairs(parts) do
      if type(slot) == "string" and type(part) == "string" and part ~= "" then items[#items + 1] = slot .. "=" .. part end
    end
    table.sort(items)
    hash = hashText(table.concat(items, ";"))
  elseif model then
    hash = "model:" .. model
  end
end

-------------------------------------------------------------------------------
-- wear effects
-------------------------------------------------------------------------------
local function applyBrakes(coef)
  if wheels and type(wheels.scaleBrakeTorque) == "function" then
    return pcall(wheels.scaleBrakeTorque, coef)
  end
  return false
end

-- Same method BeamNG uses for a flat tire: scale the tread's friction from its original values.
local function applyTires(coef)
  if not obj or not v or not v.data or type(v.data.wheels) ~= "table" or type(v.data.nodes) ~= "table" then return false end
  for wheelId, wheel in pairs(v.data.wheels) do
    local live = wheels and wheels.wheels and wheels.wheels[wheelId]
    local deflated = live and live.isTireDeflated
    if type(wheel) == "table" and type(wheel.treadNodes) == "table" and not deflated then
      for _, cid in pairs(wheel.treadNodes) do
        local node = v.data.nodes[cid]
        if node and num(node.frictionCoef) then
          local fc = node.frictionCoef
          local sfc = num(node.slidingFrictionCoef) or fc
          pcall(function() obj:setNodeFrictionSlidingCoefs(cid, fc * coef, sfc * coef) end)
        end
      end
    end
  end
  return true
end

-- Engine power uses the same multiplier BeamNG's engine damage uses. We remove our own
-- previous factor first, so we never stack and never undo damage the game applied.
local function applyEngine(coef)
  if not powertrain or type(powertrain.getDevicesByCategory) ~= "function" then return false end
  local ok, engines = pcall(powertrain.getDevicesByCategory, "engine")
  if not ok or type(engines) ~= "table" then return false end
  for _, device in pairs(engines) do
    local state = num(device.outputTorqueState)
    if state and type(device.thermals) == "table" then -- combustion engines only
      local base = clamp(state / engineFactorInUse, 0, 1)
      device.outputTorqueState = base * coef
    end
  end
  engineFactorInUse = coef
  return true
end

local function applyCondition()
  if wanted.brakes ~= applied.brakes and applyBrakes(wanted.brakes) then applied.brakes = wanted.brakes end
  if wanted.tires ~= applied.tires and applyTires(wanted.tires) then applied.tires = wanted.tires end
  if wanted.engine ~= applied.engine and applyEngine(wanted.engine) then applied.engine = wanted.engine end
end

local function setCondition(f)
  if type(f) ~= "table" then return end
  wanted.brakes = clamp(num(f.brakes) or 1, 0.3, 1)
  wanted.tires = clamp(num(f.tires) or 1, 0.5, 1)
  wanted.engine = clamp(num(f.engine) or 1, 0.5, 1)
  applyCondition()
end

-------------------------------------------------------------------------------
-- measuring
-------------------------------------------------------------------------------
local function position()
  if not obj then return nil end
  local ok, pos = pcall(function() return obj:getPosition() end)
  if not ok or pos == nil then return nil end
  local x, y, z = num(pos.x), num(pos.y), num(pos.z)
  if not x or not y or not z then return nil end
  return x, y, z
end

local function sample(dt)
  if dt > 1 then lastX, lastSpeed = nil, nil return end
  local speed = math.abs(num(ev("airspeed")) or num(ev("wheelspeed")) or 0)
  local moving = speed >= 1
  if speed > peakSpeed then peakSpeed = speed end

  if moving then totals.drive = totals.drive + dt end

  local running = ev("engineRunning")
  if running == true or running == 1 then
    local rpm = num(ev("rpm")) or 0
    totals.engine = totals.engine + dt * clamp(rpm / 2500, 0.3, 3)
  end

  local brake = clamp(num(ev("brake_input")) or num(ev("brake")) or 0, 0, 1)
  totals.brake = totals.brake + brake * speed * dt

  local x, y, z = position()
  if x and lastX and moving then
    local dx, dy, dz = x - lastX, y - lastY, z - lastZ
    local d = math.sqrt(dx * dx + dy * dy + dz * dz)
    if d <= speed * dt * 3 + 5 then -- ignore teleports and resets
      totals.dist = totals.dist + d
      local accel = lastSpeed and math.abs(speed - lastSpeed) / dt or 0
      totals.tire = totals.tire + d * (1 + clamp((accel - 3) / 5, 0, 2))
    end
  end
  lastX, lastY, lastZ = x, y, z
  lastSpeed = speed
end

local function fuelPercent()
  if not energyStorage or type(energyStorage.getStorages) ~= "function" then return nil end
  local ok, storages = pcall(energyStorage.getStorages)
  if not ok or type(storages) ~= "table" then return nil end
  local best
  for _, s in pairs(storages) do
    local okR, ratio = pcall(function() return s.remainingRatio end)
    local okN, name = pcall(function() return s.name end)
    ratio = okR and num(ratio) or nil
    if ratio then
      if ratio > 1 then ratio = ratio / 100 end
      if okN and (name == "mainTank" or name == "mainBattery") then return clamp(ratio, 0, 1) end
      best = best or clamp(ratio, 0, 1)
    end
  end
  return best
end

local function report()
  if not obj then return end
  local okId, objectId = pcall(function() return obj:getID() end)
  if not okId or type(objectId) ~= "number" then return end
  if not model then readIdentity() end
  local running = ev("engineRunning")
  local payload = {
    objectId = objectId, token = token, model = model, hash = hash, configName = configName,
    seated = wasSeated, totals = totals, peak = peakSpeed,
    damage = beamstate and num(beamstate.damage) or nil,
    telem = {
      speed = num(ev("airspeed")) or num(ev("wheelspeed")),
      rpm = num(ev("rpm")),
      gear = ev("gear"),
      running = running == true or running == 1,
      fuel = fuelPercent()
    }
  }
  peakSpeed = 0
  local okSer, encoded = pcall(serialize, payload)
  if not okSer or type(encoded) ~= "string" then
    log("E", "TorqzGarage", "[Torqz] Could not package the vehicle report: " .. tostring(encoded))
    return
  end
  pcall(function() obj:queueGameEngineLua(string.format("extensions.hook(%q,%s)", "onTorqzGarageReport", encoded)) end)
end

local function updateGFX(dt)
  if type(dt) ~= "number" or dt <= 0 then return end

  if reapplyTimer then
    reapplyTimer = reapplyTimer - dt
    if reapplyTimer <= 0 then reapplyTimer = nil; applyCondition() end
  end

  local seated = isSeated()
  if seated ~= wasSeated then
    wasSeated = seated
    lastX, lastSpeed = nil, nil
    report() -- tell the garage right away when the player gets in or out
    reportTimer = 0
  end
  if not seated then return end

  sampleTimer = sampleTimer + dt
  if sampleTimer >= SAMPLE_EVERY then
    sample(sampleTimer)
    sampleTimer = 0
  end

  identityTimer = identityTimer + dt
  if identityTimer >= 5 then
    identityTimer = 0
    readIdentity()
  end

  reportTimer = reportTimer + dt
  if reportTimer >= REPORT_EVERY then
    reportTimer = 0
    report()
  end
end

local function onExtensionLoaded()
  readIdentity()
  _G.torqzGarageApplyCondition = setCondition
end

local function onExtensionUnloaded()
  _G.torqzGarageApplyCondition = nil
end

local function onReset()
  -- Ctrl+R / recover: keep totals, but don't count the jump as distance.
  lastX, lastSpeed = nil, nil
  -- The game restores brakes, tire friction and engine power on reset; put wear back shortly after.
  applied = {brakes = 1, tires = 1, engine = 1}
  engineFactorInUse = 1
  reapplyTimer = 0.5
end

M.onExtensionLoaded = onExtensionLoaded
M.onExtensionUnloaded = onExtensionUnloaded
M.onReset = onReset
M.updateGFX = updateGFX

-- for testing only
M._debug = function()
  return {totals = totals, model = model, hash = hash, configName = configName, token = token,
          wanted = wanted, applied = applied, engineFactorInUse = engineFactorInUse}
end

return M
