-- Torqz Garage 2.0 | Torqz Mods
-- Loads the garage when the mod is active.
load("torqzGarage")
setExtensionUnloadMode("torqzGarage", "manual")
