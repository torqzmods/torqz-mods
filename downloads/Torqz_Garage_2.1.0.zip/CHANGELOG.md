# Torqz Garage changelog

## 2.1.0 (Oct 16, 2026): first public release
Same as 2.1.0-test1, which was tested in game. Adds nothing new; the "test" label is gone.

## 2.1.0-test1 (Oct 16, 2026)
- New: **Spawn from garage.** Each car's exact parts, tuning and paint are saved; press Spawn and it appears
  next to you with its own plate, already linked. Part changes on an owned car update the saved setup.
- New: **Crash & damage history.** Crashes are detected, rated Minor/Moderate/Major with an estimated repair
  cost, and repairs (repair or reset the car) are logged in the service history.
- New: **Trip log.** Every drive over 100 m is saved with distance, time, top speed and crashes.
- New: **Milestones.** 13 badges (first mile, 100/500/1,000 miles, road trip, 100 mph, first service, and more).
- New: **Wear affects driving** (on by default, can be turned off in Settings): worn brakes lose up to 40% stopping
  power, bald tires up to 15% grip, old oil and a dirty filter up to ~21% engine power. Service fixes it.
  Uses the same game functions BeamNG uses for brake scaling, flat tires and engine damage.
- App: This drive card, unrepaired damage warning, top speed, milestone count, and Trips / Crashes /
  Milestones tabs on every car.
- 133 automated checks.

## 2.0.0-test1 (Oct 16, 2026), full rebuild
- Rebuilt from scratch: one garage file, one vehicle file, one app. Much simpler and easier to fix.
- New app in the Torqz neon style with This car, My garage and Service tabs, plus mini mode.
- New: cars are recognized automatically when you spawn them again.
- New: wear and service for engine oil, tires, brakes and air filter, with warnings and a service log.
- New: car profile (year, make, model, trim, color, plate, purchase date and price) and owner info
  (owner name, nickname, how you got it).
- New: kilometers or miles, default owner name.
- Saving writes a checked temp file first and keeps a backup; a damaged save is never overwritten.
- New save location: settings/torqz_garage (the 1.x save in settings/torqzGarage is left untouched).
- 71 automated checks run against a fake BeamNG before every build.

## 0.1.0-pretest (1.x)
- First version. Add to Garage confirmed working in game on Oct 16, 2026.
