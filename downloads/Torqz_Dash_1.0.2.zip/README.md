# Torqz Dash 1.0 | Torqz Mods

A clean neon dashboard for BeamNG.drive. Works with any car, in any map.

## What it shows
- **Speed** in big numbers, mph or km/h
- **Gear** (turns red in reverse)
- **RPM bar** with a redline and a flashing **SHIFT** warning
- **Fuel** level (turns amber, then red, as it runs low)
- **Coolant and oil temperature** (warns when they run hot)
- **Indicator lights**: signals and hazards, headlights, high beams, parking brake, low fuel, check engine, ABS, traction control and stability control
- **Trip meter**: distance, time, average speed and top speed. It's saved between sessions. Press *Reset* to start a new trip.

## Buttons on the top right
- **mph / km/h**: switches units (temperatures follow: °F or °C)
- **Color dot**: cycles the color: cyan, magenta, amber, green
- **Square**: cycles the size: full, compact, mini

Your choices are remembered.

## Install
Put the .zip in your BeamNG user folder's `mods` folder (launcher → Manage User Folder → Open in Explorer).
Then in Freeroam open the UI Apps menu and add **Torqz Dash**. Drag and resize it wherever you like: the dash scales to fit the size you pick.

## Notes
- It only reads the car's live data. It doesn't change anything in your game and needs no game scripts.
- If a car doesn't report something (a car with no oil temperature, for example), that reading is simply hidden.

Part of Torqz Mods.
