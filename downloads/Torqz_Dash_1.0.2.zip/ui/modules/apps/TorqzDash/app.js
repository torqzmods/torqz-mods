/* Torqz Dash 1.0 | Torqz Mods
   A dashboard app. It only reads the car's live data streams (electrics + engineInfo),
   so it needs no game-side Lua and works with any car. Settings and the trip meter are
   kept in the app's own browser storage. */
angular.module('beamng.apps').directive('torqzDash', ['StreamsManager', '$timeout', function (StreamsManager, $timeout) {
  return {
    restrict: 'EA',
    replace: true,
    scope: true,
    templateUrl: '/ui/modules/apps/TorqzDash/app.html',
    link: function (scope, element) {
      var KEY = 'torqzDash.v1';
      var MODES = ['full', 'compact', 'mini'];
      var THEMES = ['cyan', 'magenta', 'amber', 'green'];
      var STREAMS = ['electrics', 'engineInfo'];

      // ---- saved settings + trip (all optional: works fine if storage is unavailable) ----
      var saved = {unit: 'mph', mode: 'full', theme: 'cyan', trip: {m: 0, s: 0, top: 0}};
      try {
        var raw = window.localStorage && window.localStorage.getItem(KEY);
        if (raw) {
          var p = JSON.parse(raw);
          if (p.unit === 'mph' || p.unit === 'kmh') saved.unit = p.unit;
          if (MODES.indexOf(p.mode) >= 0) saved.mode = p.mode;
          if (THEMES.indexOf(p.theme) >= 0) saved.theme = p.theme;
          if (p.trip && isFinite(p.trip.m) && isFinite(p.trip.s) && isFinite(p.trip.top)) {
            saved.trip = {m: Math.max(0, +p.trip.m), s: Math.max(0, +p.trip.s), top: Math.max(0, +p.trip.top)};
          }
        }
      } catch (e) { /* storage blocked: keep defaults */ }
      function save() {
        try { window.localStorage && window.localStorage.setItem(KEY, JSON.stringify(saved)); } catch (e) { /* ignore */ }
      }

      scope.unit = saved.unit;
      scope.mode = saved.mode;
      scope.theme = saved.theme;
      scope.d = blank();
      var trip = saved.trip;            // meters, seconds moving, top speed m/s
      var lastT = 0, lastDigest = 0, lastSave = 0, lastData = 0;

      function blank() {
        return {has: false, speed: 0, gear: 'N', rpm: 0, rpmMax: 7000, rpmPct: 0, shift: false, fuelPct: 0, fuelClass: 'ok',
                water: null, oil: null, waterClass: '', oilClass: '', sigL: false, sigR: false, hazard: false, lowFuel: false, beam: false, high: false,
                park: false, check: false, abs: false, esc: false, tcs: false, tripDist: 0, tripTime: '0:00', tripAvg: 0, tripTop: 0, stale: false};
      }

      // ---- helpers ----
      function num(v, d) { v = +v; return isFinite(v) ? v : (d || 0); }
      function arr(a, i) { return a && (a[i] !== undefined && a[i] !== null) ? a[i] : undefined; }
      function mph() { return scope.unit === 'mph'; }
      function fmtTime(s) {
        s = Math.floor(s);
        var h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), r = s % 60;
        return h > 0 ? h + ':' + (m < 10 ? '0' : '') + m + ':' + (r < 10 ? '0' : '') + r : m + ':' + (r < 10 ? '0' : '') + r;
      }
      function temp(c) { return mph() ? Math.round(c * 9 / 5 + 32) : Math.round(c); }

      function update(streams) {
        var now = Date.now();
        var el = streams && streams.electrics;
        if (!el) return;
        var ei = streams.engineInfo;
        var d = scope.d;
        lastData = now;
        d.has = true; d.stale = false;

        // speed: wheel speed, or air speed as a fallback
        var ms = Math.abs(num(el.wheelspeed, num(el.airspeed, 0)));
        d.speed = Math.round(ms * (mph() ? 2.23694 : 3.6));

        // gear
        var g = el.gear;
        if ((g === undefined || g === null || g === '') && ei) g = arr(ei, 5);
        if (g === undefined || g === null || g === '') g = num(el.gearIndex, 0) < 0 ? 'R' : (num(el.gearIndex, 0) === 0 ? 'N' : String(el.gearIndex));
        d.gear = String(g).toUpperCase().slice(0, 2);

        // rpm
        var max = num(arr(ei, 1), 0);
        if (max < 1000) max = d.rpmMax || 7000;
        if (max !== d.rpmMax) { d.rpmMax = max; scope.rpmTicks = makeTicks(max); }
        var rpm = Math.max(0, num(el.rpmTacho, num(el.rpm, 0)));
        d.rpm = Math.round(rpm);
        d.rpmPct = Math.max(0, Math.min(100, rpm / max * 100));
        d.shift = d.rpmPct >= 92 && d.gear !== 'N' && d.gear !== 'P';

        // fuel (0..1)
        var f = Math.max(0, Math.min(1, num(el.fuel, 0)));
        d.fuelPct = Math.round(f * 100);
        d.fuelClass = f <= 0.1 ? 'bad' : (f <= 0.25 ? 'warn' : 'ok');
        d.lowFuel = num(el.lowfuel, 0) > 0;

        // temperatures (game gives Celsius)
        if (el.watertemp !== undefined) {
          var wc = num(el.watertemp, 0);
          d.water = temp(wc); d.waterClass = wc >= 118 ? 'bad' : (wc >= 108 ? 'warn' : '');
        } else { d.water = null; d.waterClass = ''; }
        if (el.oiltemp !== undefined) {
          var oc = num(el.oiltemp, 0);
          d.oil = temp(oc); d.oilClass = oc >= 150 ? 'bad' : (oc >= 130 ? 'warn' : '');
        } else { d.oil = null; d.oilClass = ''; }

        // indicators
        d.sigL = num(el.signal_L, 0) > 0.5;
        d.sigR = num(el.signal_R, 0) > 0.5;
        d.hazard = num(el.hazard_enabled, num(el.hazard, 0)) > 0;
        var ls = num(el.lights_state, 0);
        d.beam = ls === 1; d.high = ls === 2 || num(el.highbeam, 0) > 0;
        d.park = num(el.parkingbrake, num(el.parkingbrakelight, 0)) > 0;
        d.check = num(el.checkengine, 0) > 0;
        d.abs = num(el.abs, 0) > 0;
        d.esc = num(el.esc, 0) > 0;
        d.tcs = num(el.tcs, 0) > 0;

        // trip meter
        if (lastT) {
          var dt = (now - lastT) / 1000;
          if (dt > 0 && dt < 0.5 && ms > 0.3) {
            trip.m += ms * dt; trip.s += dt;
            if (ms > trip.top) trip.top = ms;
          }
        }
        lastT = now;
        var dist = mph() ? trip.m / 1609.344 : trip.m / 1000;
        d.tripDist = dist < 10 ? Math.round(dist * 100) / 100 : (dist < 100 ? Math.round(dist * 10) / 10 : Math.round(dist));
        d.tripTime = fmtTime(trip.s);
        d.tripAvg = trip.s > 1 ? Math.round(trip.m / trip.s * (mph() ? 2.23694 : 3.6)) : 0;
        d.tripTop = Math.round(trip.top * (mph() ? 2.23694 : 3.6));

        if (now - lastSave > 5000) { lastSave = now; save(); }
        // redraw at most ~30 times a second
        if (now - lastDigest > 33) { lastDigest = now; scope.$applyAsync(); }
      }

      // ---- buttons ----
      scope.toggleUnit = function () { scope.unit = mph() ? 'kmh' : 'mph'; saved.unit = scope.unit; save(); };
      scope.cycleMode = function () { scope.mode = MODES[(MODES.indexOf(scope.mode) + 1) % MODES.length]; saved.mode = scope.mode; save(); };
      scope.setMode = function (m) { scope.mode = m; saved.mode = m; save(); };
      scope.cycleTheme = function () { scope.theme = THEMES[(THEMES.indexOf(scope.theme) + 1) % THEMES.length]; saved.theme = scope.theme; save(); };
      scope.resetTrip = function () { trip.m = 0; trip.s = 0; trip.top = 0; save(); };
      scope.unitLabel = function () { return mph() ? 'mph' : 'km/h'; };
      scope.distLabel = function () { return mph() ? 'mi' : 'km'; };
      scope.tempLabel = function () { return mph() ? '°F' : '°C'; };
      scope.rpmClip = function () { return 100 - scope.d.rpmPct; };
      function makeTicks(max) {
        var step = max > 9500 ? 2000 : 1000, out = [];
        for (var r = 0; r <= max; r += step) out.push({label: String(r / 1000), pos: Math.round(r / max * 1000) / 10});
        return out;
      }
      scope.rpmTicks = makeTicks(7000);
      scope.modeLabel = function () { return scope.mode === 'full' ? 'Full' : (scope.mode === 'compact' ? 'Compact' : 'Mini'); };

      // The dash is drawn at a fixed design size and scaled to fit whatever size you drag the app to.
      var DESIGN = {full: 284, compact: 214, mini: 100}, DESIGN_W = 460;
      scope.scale = 1; scope.designH = DESIGN.full;
      function fit() {
        var el = element && element[0];
        if (!el) return;
        var w = el.clientWidth, h = el.clientHeight;
        if (!w || !h) return;
        var dh = DESIGN[scope.mode] || DESIGN.full;
        var sc = Math.max(0.3, Math.min(w / DESIGN_W, h / dh, 3));
        if (Math.abs(sc - scope.scale) > 0.002 || dh !== scope.designH) { scope.scale = Math.round(sc * 1000) / 1000; scope.designH = dh; scope.$applyAsync(); }
      }
      scope.$watch('mode', fit);
      var ro = null;
      if (typeof ResizeObserver !== 'undefined' && element && element[0]) { ro = new ResizeObserver(fit); ro.observe(element[0]); }
      var fitIv = setInterval(fit, 500);   // fallback if ResizeObserver isn't available
      $timeout(fit, 0);

      // If the data stops (game paused, or you left the car) keep the last values and mark them Paused.
      var iv = setInterval(function () {
        if (scope.d.has && !scope.d.stale && Date.now() - lastData > 1200) { scope.d.stale = true; scope.$applyAsync(); }
      }, 500);

      StreamsManager.add(STREAMS);
      scope.$on('streamsUpdate', function (event, streams) { update(streams); });
      scope.$on('$destroy', function () {
        StreamsManager.remove(STREAMS);
        clearInterval(iv); clearInterval(fitIv); if (ro) ro.disconnect();
        save();
      });
    }
  };
}]);
