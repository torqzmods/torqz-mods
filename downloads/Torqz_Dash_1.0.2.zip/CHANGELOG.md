# Torqz Dash changelog

## 1.0.2 (Oct 17, 2026)
- Fixed: pausing the game no longer blanks the dash. It keeps the last readings and shows a Paused tag.
- Fixed: switching to a car without temperature sensors no longer leaves the old car's temperatures on screen.
- The speed number stays put as digits change, and the unit no longer jumps.
- RPM bar now has a real scale (1, 2, 3... x1000) that fits each engine, and a marked redline zone.
- Turn signals sit beside the speed. New fuel and check-engine icons replace the emoji. Brighter small text.
- The size button shows the current size. Keyboard focus is visible.

## 1.0.1 (Oct 17, 2026)
Smaller by default (320 x 190). The dash now scales to any size you drag the app to.

## 1.0.0 (Oct 17, 2026)
First release. Speed, gear, RPM with shift light, fuel, coolant and oil temperature, indicator lights, and a saved trip meter.
Full, compact and mini sizes, four colors, mph or km/h.
