-- Torqz Garage | Torqz Mods
-- GameEngine Lua: owns the garage save, recognizes your cars, tracks wear, service,
-- crashes, trips and milestones, spawns saved cars, and answers the in-game app.
-- Vehicle Lua (torqzGarageVehicle.lua) reports measurements and applies wear effects.

local M = {}

local TAG = "TorqzGarage"
local VERSION = "2.2.0"

local SAVE_DIR = "/settings/torqz_garage"
local SAVE_FILE = SAVE_DIR .. "/garage.json"
local TMP_FILE = SAVE_DIR .. "/garage.tmp.json"
local BACKUP_FILE = SAVE_DIR .. "/garage.backup.json"
local SCHEMA = 2

-- Wear: how much "use" each part takes before it needs a service.
M.PARTS = {
  {key = "oil",    label = "Engine oil", source = "engine", life = 7200},   -- ~2 hours of normal engine running
  {key = "tires",  label = "Tires",      source = "tire",   life = 400000}, -- ~250 miles, less if driven hard
  {key = "brakes", label = "Brakes",     source = "brake",  life = 4000},   -- ~130 hard stops
  {key = "filter", label = "Air filter", source = "dist",   life = 600000}  -- ~370 miles
}
local PART_BY_KEY = {}
for _, p in ipairs(M.PARTS) do PART_BY_KEY[p.key] = p end
local DUE_AT = 20 -- health % that triggers "service now"
local DUE_ESTIMATE_MIN = 1609   -- meters driven since a service before "due in" is guessed
-- Settings > Wear speed: how fast parts wear compared to normal.
local WEAR_SPEEDS = {easy = 0.5, normal = 1, hard = 2}

-- Crashes: beamstate.damage jumps on impact and drops back to ~0 on repair/reset.
local CRASH_MIN_DAMAGE = 1500   -- smaller bumps are ignored
local CRASH_MERGE_SECONDS = 4   -- hits this close together count as one crash
local COST_PER_DAMAGE = 0.1     -- estimated repair dollars per damage point

-- Trips
local TRIP_MIN_METERS = 100
local TRIP_IDLE_END = 300       -- seconds parked before a trip ends by itself

local MPH = 0.44704
local MILE = 1609.344

local PROFILE_FIELDS = {
  nickname = 40, year = 4, make = 30, modelName = 40, trim = 40, color = 30,
  plate = 12, purchaseDate = 20, purchasePrice = 16, ownerName = 40, acquired = 24
}
local SOLD_FIELDS = {price = 16, buyer = 40, reason = 24}
local SOLD_REASONS = {["Sold"] = true, ["Traded in"] = true, ["Scrapped"] = true, ["Gave away"] = true, ["Retired"] = true}
local ACQUIRED = {
  ["Bought new"] = true, ["Bought used"] = true, ["Built it"] = true,
  ["Gift"] = true, ["Won it"] = true, ["Other"] = true, [""] = true
}

-- Milestones: checked whenever something about a car changes.
M.MILESTONES = {
  {key = "mile1",     label = "First mile",        hint = "Drive 1 mile",                 test = function(r) return r.usage.meters >= MILE end},
  {key = "mile100",   label = "100 miles",         hint = "Drive 100 miles",              test = function(r) return r.usage.meters >= 100 * MILE end},
  {key = "mile500",   label = "500 miles",         hint = "Drive 500 miles",              test = function(r) return r.usage.meters >= 500 * MILE end},
  {key = "mile1000",  label = "1,000 miles",       hint = "Drive 1,000 miles",            test = function(r) return r.usage.meters >= 1000 * MILE end},
  {key = "mile5000",  label = "Long hauler",       hint = "Drive 5,000 miles",            test = function(r) return r.usage.meters >= 5000 * MILE end},
  {key = "hour1",     label = "Seat time",         hint = "Drive for 1 hour",             test = function(r) return r.usage.seconds >= 3600 end},
  {key = "hour10",    label = "Daily driver",      hint = "Drive for 10 hours",           test = function(r) return r.usage.seconds >= 36000 end},
  {key = "trip50",    label = "Road trip",         hint = "50 miles in one drive",        test = function(r, c) return c.tripMeters and c.tripMeters >= 50 * MILE end},
  {key = "marathon",  label = "Marathon",          hint = "Drive 2 hours in one go",      test = function(r, c) return c.tripSeconds and c.tripSeconds >= 7200 end},
  {key = "trips25",   label = "Regular",           hint = "Log 25 drives",                test = function(r) return r.stats.trips >= 25 end},
  {key = "clean10",   label = "Clean streak",      hint = "10 drives in a row with no crash", test = function(r) return r.stats.cleanStreak >= 10 end},
  {key = "speed100",  label = "Ton up",            hint = "Hit 100 mph",                  test = function(r) return r.stats.topSpeed >= 100 * MPH end},
  {key = "speed150",  label = "Speed demon",       hint = "Hit 150 mph",                  test = function(r) return r.stats.topSpeed >= 150 * MPH end},
  {key = "service1",  label = "First service",     hint = "Service any part",             test = function(r) return r.stats.services >= 1 end},
  {key = "service10", label = "Well maintained",   hint = "10 services",                  test = function(r) return r.stats.services >= 10 end},
  {key = "crash1",    label = "First scratch",     hint = "Have your first crash",        test = function(r) return r.stats.crashes >= 1 end},
  {key = "repair1",   label = "Good as new",       hint = "Repair crash damage",          test = function(r) return r.stats.repairs >= 1 end},
  {key = "repair5",   label = "Comeback kid",      hint = "Repair crash damage 5 times",  test = function(r) return r.stats.repairs >= 5 end},
  {key = "profile",   label = "Fully documented",  hint = "Fill in year, make, model, color and plate", test = function(r)
    local p = r.profile
    return p.year ~= "" and p.make ~= "" and p.modelName ~= "" and p.color ~= "" and p.plate ~= ""
  end},
}

local garage = nil
local saveAllowed = false
local loadProblem = nil
local dirty = false
local saveTimer, cleanupTimer, conditionTimer = 0, 0, 0
local live = {}       -- [objectId] = runtime info about a spawned vehicle
local toasts, toastSeq = {}, 0

-------------------------------------------------------------------------------
-- helpers
-------------------------------------------------------------------------------
local function trace(message) log("I", TAG, "[Torqz] " .. message) end
local function warn(message) log("W", TAG, "[Torqz] " .. message) end

local function now()
  local ok, value = pcall(os.time)
  if ok and type(value) == "number" then return value end
  return 0
end

local function num(value)
  if type(value) == "number" and value == value and value ~= math.huge and value ~= -math.huge then
    return value
  end
  return nil
end

local function clamp(x, a, b) if x < a then return a elseif x > b then return b end return x end

local function cleanText(value, maxLen)
  if type(value) == "number" then value = tostring(value) end
  if type(value) ~= "string" then return "" end
  value = value:gsub("[%c]", " "):gsub("^%s+", ""):gsub("%s+$", "")
  if #value > maxLen then value = value:sub(1, maxLen) end
  return value
end

local function copy(value, depth)
  depth = depth or 0
  if type(value) ~= "table" or depth > 20 then return value end
  local out = {}
  for k, v in pairs(value) do out[k] = copy(v, depth + 1) end
  return out
end

local function toast(text, kind)
  toastSeq = toastSeq + 1
  toasts[#toasts + 1] = {id = toastSeq, text = text, kind = kind or "info"}
  while #toasts > 6 do table.remove(toasts, 1) end
end

local function count(t)
  local n = 0
  for _ in pairs(t or {}) do n = n + 1 end
  return n
end

local function list(value)
  local out = {}
  if type(value) == "table" then
    for _, entry in pairs(value) do
      if type(entry) == "table" then out[#out + 1] = entry end
    end
  end
  return out
end

local function money(value)
  local n = math.floor((value or 0) + 0.5)
  local s = tostring(n):reverse():gsub("(%d%d%d)", "%1,"):reverse():gsub("^,", "")
  return "$" .. s
end

-------------------------------------------------------------------------------
-- saving and loading
-------------------------------------------------------------------------------
local function emptyGarage()
  return {schemaVersion = SCHEMA, nextSeq = 1,
          settings = {units = "mph", ownerName = "", wearAffectsDriving = true, wearSpeed = "normal"}, vehicles = {}}
end

local function validGarage(data)
  return type(data) == "table" and data.schemaVersion == SCHEMA
    and type(data.vehicles) == "table" and type(data.nextSeq) == "number"
end

local function readJson(path)
  if not FS:fileExists(path) then return nil end
  local ok, data = pcall(jsonReadFile, path)
  if ok then return data end
  return nil
end

local function ensureDir()
  if FS:directoryExists(SAVE_DIR) then return true end
  pcall(function() FS:directoryCreate(SAVE_DIR, true) end)
  return FS:directoryExists(SAVE_DIR)
end

local function sortedByAt(entries)
  local out = {}
  for _, e in ipairs(list(entries)) do if num(e.at) or num(e.startedAt) then out[#out + 1] = e end end
  table.sort(out, function(a, b) return (a.at or a.startedAt) < (b.at or b.startedAt) end)
  return out
end

local function normalizeRecord(id, rec)
  if type(rec) ~= "table" then return nil end
  rec.id = id
  rec.model = type(rec.model) == "string" and rec.model or "unknown"
  rec.profile = type(rec.profile) == "table" and rec.profile or {}
  for field, maxLen in pairs(PROFILE_FIELDS) do rec.profile[field] = cleanText(rec.profile[field], maxLen) end
  rec.notes = cleanText(rec.notes, 1000)
  rec.favorite = rec.favorite == true
  rec.usage = type(rec.usage) == "table" and rec.usage or {}
  rec.usage.meters = num(rec.usage.meters) or 0
  rec.usage.seconds = num(rec.usage.seconds) or 0
  rec.wear = type(rec.wear) == "table" and rec.wear or {}
  for _, p in ipairs(M.PARTS) do rec.wear[p.key] = math.max(0, num(rec.wear[p.key]) or 0) end
  rec.alerts = type(rec.alerts) == "table" and rec.alerts or {}
  rec.service = sortedByAt(rec.service)
  rec.crashes = sortedByAt(rec.crashes)
  rec.trips = sortedByAt(rec.trips)
  rec.badges = type(rec.badges) == "table" and rec.badges or {}
  rec.stats = type(rec.stats) == "table" and rec.stats or {}
  rec.stats.topSpeed = num(rec.stats.topSpeed) or 0
  rec.stats.crashes = num(rec.stats.crashes) or #rec.crashes
  rec.stats.repairs = num(rec.stats.repairs) or 0
  rec.stats.services = num(rec.stats.services) or #rec.service
  rec.stats.trips = num(rec.stats.trips) or #rec.trips
  if not num(rec.stats.cleanStreak) then
    local streak = 0
    for i = #rec.trips, 1, -1 do
      if (rec.trips[i].crashes or 0) > 0 then break end
      streak = streak + 1
    end
    rec.stats.cleanStreak = streak
  end
  -- odometer reading at each part's last service (for the "due in" guess)
  rec.serviceMeters = type(rec.serviceMeters) == "table" and rec.serviceMeters or {}
  for _, p in ipairs(M.PARTS) do
    if not num(rec.serviceMeters[p.key]) then
      local at = 0
      for _, e in ipairs(rec.service) do
        for _, key in ipairs(type(e.items) == "table" and e.items or {}) do
          if key == p.key then at = num(e.meters) or at end
        end
      end
      rec.serviceMeters[p.key] = at
    end
  end
  if type(rec.sold) == "table" then
    local sold = {at = num(rec.sold.at) or now()}
    for field, maxLen in pairs(SOLD_FIELDS) do sold[field] = cleanText(rec.sold[field], maxLen) end
    if not SOLD_REASONS[sold.reason] then sold.reason = "Sold" end
    rec.sold = sold
  else
    rec.sold = nil
  end
  if type(rec.config) ~= "table" then rec.config = nil end
  rec.createdAt = num(rec.createdAt) or now()
  rec.lastUsedAt = num(rec.lastUsedAt) or rec.createdAt
  return rec
end

local function adoptGarage(data)
  garage = data
  garage.settings = type(garage.settings) == "table" and garage.settings or {}
  garage.settings.units = garage.settings.units == "kmh" and "kmh" or "mph"
  garage.settings.ownerName = cleanText(garage.settings.ownerName, PROFILE_FIELDS.ownerName)
  garage.settings.wearAffectsDriving = garage.settings.wearAffectsDriving ~= false
  garage.settings.wearSpeed = WEAR_SPEEDS[garage.settings.wearSpeed] and garage.settings.wearSpeed or "normal"
  local fixed = {}
  for id, rec in pairs(garage.vehicles) do
    if type(id) == "string" then fixed[id] = normalizeRecord(id, rec) end
  end
  garage.vehicles = fixed
end

local function loadGarage()
  saveAllowed, loadProblem = false, nil
  if not ensureDir() then
    loadProblem = "Could not create the save folder. Saving is turned off."
    adoptGarage(emptyGarage())
    return
  end
  if not FS:fileExists(SAVE_FILE) then
    adoptGarage(emptyGarage())
    saveAllowed = true
    return
  end
  local main = readJson(SAVE_FILE)
  if validGarage(main) then
    adoptGarage(main)
    saveAllowed = true
    return
  end
  local backup = readJson(BACKUP_FILE)
  if validGarage(backup) then
    adoptGarage(backup)
    saveAllowed = true
    warn("Main garage file was unreadable; loaded the backup instead.")
    toast("Your garage file was damaged, so the backup was loaded.", "warn")
    return
  end
  loadProblem = "Your garage file couldn't be read. Saving is paused so nothing gets overwritten."
  warn(loadProblem)
  adoptGarage(emptyGarage())
end

local function saveNow()
  if not saveAllowed or not garage then return false end
  if not ensureDir() then warn("Save failed: no save folder.") return false end
  garage.savedAt = now()
  garage.version = VERSION

  local ok = pcall(jsonWriteFile, TMP_FILE, garage, true)
  if not ok or not validGarage(readJson(TMP_FILE)) then
    warn("Save failed while writing the temporary file. Your last save is untouched.")
    return false
  end
  if validGarage(readJson(SAVE_FILE)) then
    pcall(function() FS:removeFile(BACKUP_FILE) end)
    pcall(function() FS:copyFile(SAVE_FILE, BACKUP_FILE) end)
  end
  ok = pcall(jsonWriteFile, SAVE_FILE, garage, true)
  if not ok or not validGarage(readJson(SAVE_FILE)) then
    warn("Save failed while writing the garage file; restoring the backup.")
    if validGarage(readJson(BACKUP_FILE)) then
      pcall(function() FS:copyFile(BACKUP_FILE, SAVE_FILE) end)
    end
    return false
  end
  pcall(function() FS:removeFile(TMP_FILE) end)
  dirty = false
  saveTimer = 0
  return true
end

-------------------------------------------------------------------------------
-- records
-------------------------------------------------------------------------------
local function health(rec, key)
  local part = PART_BY_KEY[key]
  return clamp(100 - (rec.wear[key] or 0) / part.life * 100, 0, 100)
end

local function displayName(rec)
  local p = rec.profile
  if p.nickname ~= "" then return p.nickname end
  local parts = {}
  for _, s in ipairs({p.year, p.make, p.modelName}) do if s ~= "" then parts[#parts + 1] = s end end
  if #parts > 0 then return table.concat(parts, " ") end
  return rec.model
end

local function checkBadges(rec, ctx)
  ctx = ctx or {}
  for _, m in ipairs(M.MILESTONES) do
    if not rec.badges[m.key] then
      local ok, earned = pcall(m.test, rec, ctx)
      if ok and earned then
        rec.badges[m.key] = now()
        dirty = true
        toast("Milestone unlocked: " .. m.label .. " (" .. displayName(rec) .. ")", "badge")
      end
    end
  end
end

local function linkedIds()
  local ids = {}
  for _, info in pairs(live) do if info.recordId then ids[info.recordId] = true end end
  return ids
end

local function playerObjectId()
  if not be then return nil end
  local veh = be:getPlayerVehicle(0)
  if not veh then return nil end
  local ok, id = pcall(function() return veh:getID() end)
  if ok and type(id) == "number" then return id end
  return nil
end

local function vehicleObject(objectId)
  local ok, veh = pcall(function() return be:getObjectByID(objectId) end)
  if ok then return veh end
  return nil
end

local function modelOf(objectId)
  local info = live[objectId]
  if info and info.model then return info.model end
  local veh = vehicleObject(objectId)
  if not veh then return nil end
  local okName, name = pcall(function() return veh:getJBeamFilename() end)
  if okName and type(name) == "string" and name ~= "" then return name end
  return nil
end

local function liveInfo(objectId)
  local info = live[objectId]
  if not info then
    info = {objectId = objectId, session = {meters = 0, seconds = 0}}
    live[objectId] = info
  end
  return info
end

-- Remember the car's exact parts, tuning and paint so it can be spawned later.
-- Mirrors how BeamNG's own "save config" builds a .pc file.
local function captureConfig(objectId, rec)
  if not rec or not core_vehicle_manager or type(core_vehicle_manager.getVehicleData) ~= "function" then return end
  local ok, data = pcall(core_vehicle_manager.getVehicleData, objectId)
  if not ok or type(data) ~= "table" or type(data.config) ~= "table" then return end
  local cfg = copy(data.config)
  if type(cfg.partsTree) == "table" and core_vehicle_partmgmt
    and type(core_vehicle_partmgmt.partsTreeToPartsMap) == "function" then
    local okMap, parts = pcall(core_vehicle_partmgmt.partsTreeToPartsMap, cfg.partsTree)
    if okMap and type(parts) == "table" then
      cfg.parts = parts
      cfg.partsTree = nil
    end
  end
  cfg.model = data.model or cfg.model or rec.model
  cfg.format, cfg.mainPartPath, cfg.linkedPCFile, cfg.partsCondition = nil, nil, nil, nil
  if cfg.model ~= rec.model then return end
  rec.config = cfg
  dirty = true
end

-------------------------------------------------------------------------------
-- wear effects on driving (applied by Vehicle Lua)
-------------------------------------------------------------------------------
local function conditionFactors(rec)
  if not rec or not garage.settings.wearAffectsDriving then return {brakes = 1, tires = 1, engine = 1} end
  local brakes, tires, oil, filter = health(rec, "brakes"), health(rec, "tires"), health(rec, "oil"), health(rec, "filter")
  local f = {}
  f.brakes = brakes >= 50 and 1 or 0.6 + 0.4 * (brakes / 50)    -- worn pads: up to 40% less stopping power
  f.tires = tires >= 40 and 1 or 0.85 + 0.15 * (tires / 40)      -- bald tires: up to 15% less grip
  local oilF = oil >= 20 and 1 or 0.85 + 0.15 * (oil / 20)       -- old oil: up to 15% less power
  local filterF = filter >= 30 and 1 or 0.93 + 0.07 * (filter / 30) -- clogged filter: up to 7% less power
  f.engine = oilF * filterF
  return f
end

local function pushCondition(objectId, rec, force)
  local info = live[objectId]
  if not info then return end
  local f = conditionFactors(rec)
  local key = string.format("%.3f/%.3f/%.3f", f.brakes, f.tires, f.engine)
  if not force and info.conditionKey == key then return end
  local veh = vehicleObject(objectId)
  if not veh then return end
  local cmd = string.format("if torqzGarageApplyCondition then torqzGarageApplyCondition({brakes=%.3f,tires=%.3f,engine=%.3f}) end",
    f.brakes, f.tires, f.engine)
  local ok = pcall(function() veh:queueLuaCommand(cmd) end)
  if ok then info.conditionKey = key end
end

-------------------------------------------------------------------------------
-- trips
-------------------------------------------------------------------------------
local function endTrip(info, rec)
  local trip = info.trip
  info.trip = nil
  if not trip or not rec or trip.meters < TRIP_MIN_METERS then return end
  rec.trips[#rec.trips + 1] = {
    startedAt = trip.startedAt, endedAt = now(), meters = trip.meters, seconds = trip.seconds,
    topSpeed = trip.topSpeed, crashes = trip.crashes
  }
  while #rec.trips > 50 do table.remove(rec.trips, 1) end
  rec.stats.trips = rec.stats.trips + 1
  rec.stats.cleanStreak = (trip.crashes or 0) > 0 and 0 or rec.stats.cleanStreak + 1
  dirty = true
  checkBadges(rec, {tripMeters = trip.meters, tripSeconds = trip.seconds})
end

local function unlink(info, keepTrip)
  local rec = info.recordId and garage.vehicles[info.recordId]
  if rec and not keepTrip then endTrip(info, rec) end
  info.recordId = nil
  info.crashOpen = nil
  pushCondition(info.objectId, nil)
end

local function link(info, rec, welcome)
  if info.recordId and info.recordId ~= rec.id then unlink(info) end
  info.recordId = rec.id
  info.declined = nil
  info.trip = nil
  rec.lastUsedAt = now()
  dirty = true
  if welcome then toast("Welcome back, " .. displayName(rec) .. ".", "good") end
  trace("Linked vehicle " .. tostring(info.objectId) .. " to " .. rec.id)
  pushCondition(info.objectId, rec, true)
end

local function tryAutoConnect(info)
  if not info.model or not info.hash then return end
  local taken, best = linkedIds(), nil
  for id, rec in pairs(garage.vehicles) do
    if not taken[id] and not rec.sold and rec.model == info.model and rec.partsHash == info.hash then
      if not best or rec.lastUsedAt > best.lastUsedAt then best = rec end
    end
  end
  if best then link(info, best, true) end
end

-------------------------------------------------------------------------------
-- usage, wear, crashes
-------------------------------------------------------------------------------
local function applyUsage(rec, d)
  rec.usage.meters = rec.usage.meters + d.dist
  rec.usage.seconds = rec.usage.seconds + d.drive
  local speed = WEAR_SPEEDS[garage.settings.wearSpeed] or 1
  for _, part in ipairs(M.PARTS) do
    local before = health(rec, part.key)
    rec.wear[part.key] = rec.wear[part.key] + (d[part.source] or 0) * speed
    local after = health(rec, part.key)
    if before > DUE_AT and after <= DUE_AT and not rec.alerts[part.key] then
      rec.alerts[part.key] = true
      toast(displayName(rec) .. ": " .. part.label .. " needs a service.", "warn")
    end
  end
  if d.dist > 0 or d.drive > 0 then
    rec.lastUsedAt = now()
    dirty = true
  end
end

local function unrepairedCost(rec)
  local total = 0
  for _, c in ipairs(rec.crashes) do if not c.repaired then total = total + (c.cost or 0) end end
  return total
end

local function trackDamage(info, rec, damage, speedBefore)
  if not damage then return end
  local last = info.lastDamage
  info.lastDamage = damage
  if last == nil or not rec then return end -- first reading is the baseline

  local increase = damage - last
  if increase >= CRASH_MIN_DAMAGE or (info.crashOpen and increase > 0 and now() - info.crashOpen.at <= CRASH_MERGE_SECONDS) then
    local cost = increase * COST_PER_DAMAGE
    local open = info.crashOpen
    if open and now() - open.at <= CRASH_MERGE_SECONDS then
      open.damage = open.damage + increase
      open.cost = open.cost + cost
    else
      open = {at = now(), meters = rec.usage.meters, damage = increase, cost = cost, speed = speedBefore or 0, repaired = false}
      rec.crashes[#rec.crashes + 1] = open
      while #rec.crashes > 50 do table.remove(rec.crashes, 1) end
      rec.stats.crashes = rec.stats.crashes + 1
      if info.trip then info.trip.crashes = info.trip.crashes + 1 end
      info.crashOpen = open
      toast("Crash logged on " .. displayName(rec) .. ".", "error")
    end
    open.severity = open.cost < 1000 and "Minor" or (open.cost < 5000 and "Moderate" or "Major")
    dirty = true
    checkBadges(rec)
  elseif last >= CRASH_MIN_DAMAGE and damage < last * 0.2 then
    -- damage went away: the car was repaired or reset
    local cost = unrepairedCost(rec)
    if cost > 0 then
      for _, c in ipairs(rec.crashes) do c.repaired = true end
      rec.service[#rec.service + 1] = {at = now(), meters = rec.usage.meters, kind = "repair", cost = cost, items = {}}
      while #rec.service > 100 do table.remove(rec.service, 1) end
      rec.stats.repairs = rec.stats.repairs + 1
      info.crashOpen = nil
      dirty = true
      toast(displayName(rec) .. " repaired (about " .. money(cost) .. ").", "good")
      checkBadges(rec)
    end
  end
end

-------------------------------------------------------------------------------
-- vehicle reports (sent about once a second by torqzGarageVehicle.lua)
-------------------------------------------------------------------------------
local TOTAL_KEYS = {"dist", "drive", "tire", "brake", "engine"}
local MAX_PER_REPORT = {dist = 3000, drive = 30, tire = 9000, brake = 3000, engine = 90}

local function onTorqzGarageReport(p)
  if type(p) ~= "table" or type(p.objectId) ~= "number" or not garage then return end
  local isNew = live[p.objectId] == nil
  local info = liveInfo(p.objectId)
  info.model = type(p.model) == "string" and p.model or info.model
  info.configName = type(p.configName) == "string" and p.configName or info.configName
  info.telem = type(p.telem) == "table" and p.telem or nil
  local wasSeated = info.seated
  info.seated = p.seated == true
  info.missing = 0

  local rec = info.recordId and garage.vehicles[info.recordId]
  if info.recordId and not rec then info.recordId = nil end

  -- An owned car got new parts: keep it linked and remember its new setup.
  local hash = type(p.hash) == "string" and p.hash or nil
  if hash and hash ~= info.hash then
    if rec and rec.model == info.model then
      if rec.partsHash ~= hash then
        rec.partsHash, rec.configName = hash, info.configName or rec.configName
        dirty = true
      end
      if info.hash ~= nil then captureConfig(p.objectId, rec) end
    end
    info.hash = hash
  end

  -- Turn running totals into "what happened since the last report".
  local totals = type(p.totals) == "table" and p.totals or {}
  local delta = {}
  local freshVm = info.token ~= nil and info.token ~= p.token
  for _, k in ipairs(TOTAL_KEYS) do
    local total = num(totals[k]) or 0
    local d
    if isNew or not info.last then
      d = 0 -- first contact after the mod loaded: just set the baseline
    elseif freshVm or total < (info.last[k] or 0) then
      d = total -- the vehicle's Lua restarted and counts from zero again
    else
      d = total - (info.last[k] or 0)
    end
    delta[k] = clamp(d, 0, MAX_PER_REPORT[k])
  end
  info.token = p.token
  info.last = {}
  for _, k in ipairs(TOTAL_KEYS) do info.last[k] = num(totals[k]) or 0 end
  if freshVm then info.lastDamage = nil end

  info.session.meters = info.session.meters + delta.dist
  info.session.seconds = info.session.seconds + delta.drive
  local peak = num(p.peak) or 0

  if rec then
    applyUsage(rec, delta)
    if peak > rec.stats.topSpeed then rec.stats.topSpeed = peak; dirty = true end
    trackDamage(info, rec, num(p.damage), info.prevSpeed)

    -- trips
    if delta.dist > 0 then
      info.trip = info.trip or {startedAt = now(), meters = 0, seconds = 0, topSpeed = 0, crashes = 0, idle = 0}
    end
    if info.trip then
      local trip = info.trip
      trip.meters = trip.meters + delta.dist
      trip.seconds = trip.seconds + delta.drive
      if peak > trip.topSpeed then trip.topSpeed = peak end
      trip.idle = delta.dist > 0 and 0 or trip.idle + 1
      if trip.idle >= TRIP_IDLE_END then endTrip(info, rec) end
    end
    if wasSeated and not info.seated then
      endTrip(info, rec)
      captureConfig(p.objectId, rec)
    end
    if freshVm then pushCondition(p.objectId, rec, true) end
    if delta.dist > 0 or delta.drive > 0 then checkBadges(rec) end
  else
    info.lastDamage = num(p.damage)
  end
  info.prevSpeed = num(p.telem and p.telem.speed) or info.prevSpeed

  if info.seated and not info.recordId and not info.declined then
    tryAutoConnect(info)
  end
end

-------------------------------------------------------------------------------
-- player actions (from the app)
-------------------------------------------------------------------------------
local function newId()
  local seq = garage.nextSeq
  garage.nextSeq = seq + 1
  return string.format("TQZ-%04d-%04X", seq, math.random(0, 0xFFFF))
end

local actions = {}

function actions.add()
  local objectId = playerObjectId()
  if not objectId then return false, "Get in a car first." end
  local info = liveInfo(objectId)
  if info.recordId and garage.vehicles[info.recordId] then return false, "This car is already in your garage." end
  local model = modelOf(objectId)
  if not model then return false, "Couldn't read this car's model. Try again in a second." end
  local id = newId()
  local rec = normalizeRecord(id, {
    model = model, partsHash = info.hash, configName = info.configName,
    createdAt = now(), profile = {ownerName = garage.settings.ownerName, acquired = "Bought new"}
  })
  garage.vehicles[id] = rec
  captureConfig(objectId, rec)
  link(info, rec, false)
  if not saveNow() then
    garage.vehicles[id] = nil
    info.recordId = nil
    return false, "Couldn't save, so the car wasn't added. Check the game log for [Torqz]."
  end
  trace("Added " .. model .. " as " .. id .. (rec.config and " (setup saved)" or " (setup not captured)"))
  return true, "Added to your garage. Fill in its profile any time.", id
end

function actions.connect(args)
  local objectId = playerObjectId()
  local rec = garage.vehicles[args.id or ""]
  if not objectId or not rec then return false, "Pick a car from your garage." end
  if rec.sold then return false, displayName(rec) .. " is in your past cars. Bring it back first." end
  if modelOf(objectId) ~= rec.model then return false, "That record is a " .. rec.model .. ", not this car." end
  for otherId, info in pairs(live) do
    if info.recordId == rec.id and otherId ~= objectId then unlink(info) end
  end
  local info = liveInfo(objectId)
  if info.hash and info.model == rec.model then rec.partsHash, rec.configName = info.hash, info.configName end
  captureConfig(objectId, rec)
  link(info, rec, false)
  return true, "Now tracking " .. displayName(rec) .. "."
end

function actions.disconnect()
  local objectId = playerObjectId()
  local info = objectId and live[objectId]
  if not info or not info.recordId then return false, "This car isn't connected." end
  unlink(info)
  info.declined = true
  dirty = true
  return true, "Stopped tracking this car. It stays in your garage."
end

function actions.spawn(args)
  local rec = garage.vehicles[args.id or ""]
  if not rec then return false, "Car not found." end
  if rec.sold then return false, displayName(rec) .. " is in your past cars. Bring it back first." end
  if linkedIds()[rec.id] then return false, displayName(rec) .. " is already on the road." end
  if not core_vehicles or type(core_vehicles.spawnNewVehicle) ~= "function" then
    return false, "Spawning isn't available here."
  end
  local options = {autoEnterVehicle = true}
  if rec.config then
    options.config = copy(rec.config)
  elseif rec.configName then
    options.config = rec.configName
  end
  if rec.profile.plate ~= "" then options.licenseText = rec.profile.plate end
  local ok, veh = pcall(core_vehicles.spawnNewVehicle, rec.model, options)
  if not ok or not veh then
    warn("Spawn failed for " .. rec.id .. ": " .. tostring(veh))
    return false, "Couldn't spawn " .. displayName(rec) .. ". Check the game log for [Torqz]."
  end
  local okId, objectId = pcall(function() return veh:getID() end)
  if okId and type(objectId) == "number" then
    link(liveInfo(objectId), rec, false)
  end
  trace("Spawned " .. rec.id .. (rec.config and " with its saved setup" or " with its default setup"))
  return true, displayName(rec) .. " is ready." .. (rec.config and "" or " (Its exact setup wasn't saved yet, so it uses the default parts.)")
end

function actions.favorite(args)
  local rec = garage.vehicles[args.id or ""]
  if not rec then return false, "Car not found." end
  rec.favorite = not rec.favorite
  dirty = true
  return true, rec.favorite and "Added to favorites." or "Removed from favorites."
end

function actions.profile(args)
  local rec = garage.vehicles[args.id or ""]
  if not rec or type(args.value) ~= "table" then return false, "Car not found." end
  local v = args.value
  for field, maxLen in pairs(PROFILE_FIELDS) do
    if v[field] ~= nil then rec.profile[field] = cleanText(v[field], maxLen) end
  end
  if not ACQUIRED[rec.profile.acquired] then rec.profile.acquired = "Other" end
  if v.notes ~= nil then rec.notes = cleanText(v.notes, 1000) end
  dirty = true
  checkBadges(rec)
  return true, "Profile saved."
end

function actions.service(args)
  local rec = garage.vehicles[args.id or ""]
  if not rec then return false, "Car not found." end
  if rec.sold then return false, "You don't own " .. displayName(rec) .. " anymore." end
  local items = {}
  if args.value == "all" then
    for _, p in ipairs(M.PARTS) do items[#items + 1] = p.key end
  elseif PART_BY_KEY[args.value] then
    items[1] = args.value
  else
    return false, "Pick what to service."
  end
  local labels = {}
  for _, key in ipairs(items) do
    rec.wear[key] = 0
    rec.alerts[key] = nil
    rec.serviceMeters[key] = rec.usage.meters
    labels[#labels + 1] = PART_BY_KEY[key].label
  end
  rec.service[#rec.service + 1] = {at = now(), meters = rec.usage.meters, items = items}
  while #rec.service > 100 do table.remove(rec.service, 1) end
  rec.stats.services = rec.stats.services + 1
  dirty = true
  checkBadges(rec)
  for objectId, info in pairs(live) do
    if info.recordId == rec.id then pushCondition(objectId, rec) end
  end
  return true, "Serviced: " .. table.concat(labels, ", ") .. "."
end

function actions.sell(args)
  local rec = garage.vehicles[args.id or ""]
  if not rec then return false, "Car not found." end
  if rec.sold then return false, displayName(rec) .. " is already in your past cars." end
  local v = type(args.value) == "table" and args.value or {}
  local sold = {at = now()}
  for field, maxLen in pairs(SOLD_FIELDS) do sold[field] = cleanText(v[field], maxLen) end
  if not SOLD_REASONS[sold.reason] then sold.reason = "Sold" end
  for _, info in pairs(live) do
    if info.recordId == rec.id then unlink(info); info.declined = true end
  end
  rec.sold = sold
  dirty = true
  return true, displayName(rec) .. " moved to your past cars. Its history is kept."
end

function actions.unsell(args)
  local rec = garage.vehicles[args.id or ""]
  if not rec then return false, "Car not found." end
  if not rec.sold then return false, displayName(rec) .. " is already in your garage." end
  rec.sold = nil
  rec.lastUsedAt = now()
  dirty = true
  return true, displayName(rec) .. " is back in your garage."
end

function actions.remove(args)
  local rec = garage.vehicles[args.id or ""]
  if not rec then return false, "Car not found." end
  local name = displayName(rec)
  for _, info in pairs(live) do
    if info.recordId == rec.id then unlink(info, true); info.declined = true end
  end
  garage.vehicles[rec.id] = nil
  dirty = true
  return true, name .. " was removed from your garage."
end

function actions.setting(args)
  if args.key == "units" and (args.value == "mph" or args.value == "kmh") then
    garage.settings.units = args.value
  elseif args.key == "ownerName" then
    garage.settings.ownerName = cleanText(args.value, PROFILE_FIELDS.ownerName)
  elseif args.key == "wearSpeed" and WEAR_SPEEDS[args.value] then
    garage.settings.wearSpeed = args.value
  elseif args.key == "wearAffectsDriving" and type(args.value) == "boolean" then
    garage.settings.wearAffectsDriving = args.value
    for objectId, info in pairs(live) do
      if info.recordId then pushCondition(objectId, garage.vehicles[info.recordId]) end
    end
  else
    return false, "Unknown setting."
  end
  dirty = true
  return true, "Settings saved."
end

local function uiAction(args)
  if type(args) ~= "table" or type(args.type) ~= "string" or not actions[args.type] then
    toast("That button didn't send a valid request.", "error")
    return
  end
  if not garage then return end
  trace("Button: " .. args.type)
  if args.type ~= "add" and args.type ~= "spawn" and not saveAllowed then
    toast(loadProblem or "Saving is turned off.", "error")
    return
  end
  local ok, result, message = pcall(actions[args.type], args)
  if not ok then
    log("E", TAG, "[Torqz] Action '" .. args.type .. "' crashed: " .. tostring(result))
    toast("Something went wrong. Check the game log for [Torqz].", "error")
    return
  end
  if result and dirty and args.type ~= "add" then
    if not saveNow() then toast("Couldn't save that change. Check the game log for [Torqz].", "error") return end
  end
  if message then toast(message, result and "good" or "error") end
end

-------------------------------------------------------------------------------
-- state for the app
-------------------------------------------------------------------------------
local function lastN(entries, n, map)
  local out = {}
  for i = #entries, math.max(1, #entries - n + 1), -1 do out[#out + 1] = map(entries[i]) end
  return out
end

-- Rough guess of how far until a part needs a service, from how fast it has worn since its last one.
local function dueIn(rec, part)
  local since = rec.usage.meters - (rec.serviceMeters[part.key] or 0)
  local wear = rec.wear[part.key] or 0
  if since < DUE_ESTIMATE_MIN or wear <= 0 then return nil end
  local left = part.life * (1 - DUE_AT / 100) - wear
  if left <= 0 then return 0 end
  return left / (wear / since)
end

local function vehicleView(rec, taken)
  local wear = {}
  for _, part in ipairs(M.PARTS) do
    wear[#wear + 1] = {key = part.key, label = part.label, health = math.floor(health(rec, part.key) + 0.5),
                       dueIn = dueIn(rec, part)}
  end
  local history = lastN(rec.service, 25, function(e)
    if e.kind == "repair" then
      return {at = e.at, meters = e.meters, items = "Crash repair", cost = e.cost, repair = true}
    end
    local names = {}
    for _, key in ipairs(type(e.items) == "table" and e.items or {}) do
      if PART_BY_KEY[key] then names[#names + 1] = PART_BY_KEY[key].label end
    end
    return {at = e.at, meters = e.meters, items = table.concat(names, ", ")}
  end)
  local trips = lastN(rec.trips, 25, function(t)
    return {startedAt = t.startedAt, endedAt = t.endedAt, meters = t.meters, seconds = t.seconds,
            topSpeed = t.topSpeed, crashes = t.crashes}
  end)
  local crashes = lastN(rec.crashes, 25, function(c)
    return {at = c.at, meters = c.meters, cost = c.cost, severity = c.severity or "Minor", speed = c.speed, repaired = c.repaired == true}
  end)
  local badges, earned = {}, 0
  for _, m in ipairs(M.MILESTONES) do
    local at = rec.badges[m.key]
    if at then earned = earned + 1 end
    badges[#badges + 1] = {key = m.key, label = m.label, hint = m.hint, at = at}
  end
  return {
    id = rec.id, name = displayName(rec), model = rec.model, configName = rec.configName,
    profile = rec.profile, notes = rec.notes, favorite = rec.favorite,
    meters = rec.usage.meters, seconds = rec.usage.seconds,
    createdAt = rec.createdAt, lastUsedAt = rec.lastUsedAt,
    live = taken[rec.id] == true, setupSaved = rec.config ~= nil, sold = rec.sold,
    wear = wear, service = history, trips = trips, crashes = crashes,
    badges = badges, badgeCount = earned, badgeTotal = #M.MILESTONES,
    stats = {topSpeed = rec.stats.topSpeed, crashes = rec.stats.crashes, repairs = rec.stats.repairs,
             trips = rec.stats.trips, services = rec.stats.services, unrepaired = unrepairedCost(rec),
             cleanStreak = rec.stats.cleanStreak},
    effects = conditionFactors(rec)
  }
end

local function buildState()
  local taken = linkedIds()
  local vehicles = {}
  local totals = {cars = 0, past = 0, meters = 0, seconds = 0, trips = 0, crashes = 0, badges = 0}
  for _, rec in pairs(garage.vehicles) do
    local view = vehicleView(rec, taken)
    vehicles[#vehicles + 1] = view
    if rec.sold then totals.past = totals.past + 1 else totals.cars = totals.cars + 1 end
    totals.meters = totals.meters + rec.usage.meters
    totals.seconds = totals.seconds + rec.usage.seconds
    totals.trips = totals.trips + rec.stats.trips
    totals.crashes = totals.crashes + rec.stats.crashes
    totals.badges = totals.badges + view.badgeCount
  end
  table.sort(vehicles, function(a, b)
    if a.favorite ~= b.favorite then return a.favorite end
    return a.lastUsedAt > b.lastUsedAt
  end)

  local current = nil
  local objectId = playerObjectId()
  if objectId then
    local info = live[objectId] or {session = {meters = 0, seconds = 0}}
    local model = modelOf(objectId)
    local suggestions = {}
    if not info.recordId and model then
      for _, rec in pairs(garage.vehicles) do
        if rec.model == model and not taken[rec.id] and not rec.sold then
          suggestions[#suggestions + 1] = {id = rec.id, name = displayName(rec)}
        end
      end
    end
    current = {
      objectId = objectId, model = model, configName = info.configName,
      recordId = info.recordId, session = info.session, telem = info.telem,
      trip = info.trip and {meters = info.trip.meters, seconds = info.trip.seconds, topSpeed = info.trip.topSpeed, crashes = info.trip.crashes} or nil,
      suggestions = suggestions
    }
  end

  return {
    version = VERSION, saveOk = saveAllowed, problem = loadProblem,
    settings = garage.settings, vehicles = vehicles, count = totals.cars, totals = totals,
    current = current, toasts = toasts
  }
end

local function uiState()
  if not garage then return '{"error":"Torqz Garage is still loading."}' end
  local ok, result = pcall(function() return jsonEncode(buildState()) end)
  if ok and type(result) == "string" then return result end
  log("E", TAG, "[Torqz] Could not build app state: " .. tostring(result))
  return '{"error":"Torqz Garage hit an error. Check the game log for [Torqz]."}'
end

-------------------------------------------------------------------------------
-- lifecycle
-------------------------------------------------------------------------------
local function onUpdate(dtReal)
  local dt = num(dtReal) or 0
  if dt <= 0 or dt > 5 or not garage then return end

  cleanupTimer = cleanupTimer + dt
  if cleanupTimer >= 2 then
    cleanupTimer = 0
    for objectId, info in pairs(live) do
      if not vehicleObject(objectId) then
        info.missing = (info.missing or 0) + 1
        if info.missing >= 2 then
          local rec = info.recordId and garage.vehicles[info.recordId]
          if rec then endTrip(info, rec); dirty = true end
          live[objectId] = nil
        end
      end
    end
  end

  conditionTimer = conditionTimer + dt
  if conditionTimer >= 10 then
    conditionTimer = 0
    for objectId, info in pairs(live) do
      if info.recordId then pushCondition(objectId, garage.vehicles[info.recordId], true) end
    end
  end

  if dirty then
    saveTimer = saveTimer + dt
    if saveTimer >= 20 then saveNow() end
  end
end

local function onExtensionLoaded()
  math.randomseed(now())
  loadGarage()
  trace("Torqz Garage " .. VERSION .. " loaded: " .. count(garage.vehicles) .. " cars, saving "
    .. (saveAllowed and "on" or "OFF (" .. tostring(loadProblem) .. ")"))
end

local function onExtensionUnloaded()
  if garage then
    for _, info in pairs(live) do
      local rec = info.recordId and garage.vehicles[info.recordId]
      if rec then endTrip(info, rec) end
    end
  end
  if dirty then saveNow() end
end

M.onExtensionLoaded = onExtensionLoaded
M.onExtensionUnloaded = onExtensionUnloaded
M.onUpdate = onUpdate
M.onTorqzGarageReport = onTorqzGarageReport
M.uiState = uiState
M.uiAction = uiAction
M.saveNow = saveNow

-- for testing only
M._debug = function() return {garage = garage, live = live, toasts = toasts} end

return M
