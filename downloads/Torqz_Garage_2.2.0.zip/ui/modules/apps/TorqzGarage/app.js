/* Torqz Garage 2.2 | Torqz Mods
   In-game app. Lua owns all saved data; this file only shows it and sends button presses. */
angular.module('beamng.apps').directive('torqzGarage', ['$interval', '$timeout', function ($interval, $timeout) {
  return {
    restrict: 'EA',
    replace: true,
    scope: true,
    templateUrl: '/ui/modules/apps/TorqzGarage/app.html',
    link: function (scope) {
      scope.tab = 'car';          // car | garage | service | settings
      scope.mini = false;
      scope.loading = true;
      scope.problem = null;
      scope.s = {vehicles: [], current: null, settings: {units: 'mph', ownerName: ''}, saveOk: true};
      scope.selectedId = null;
      scope.ui = {search: '', sortBy: 'recent', serviceId: null, ownerDraft: '', detailTab: 'overview', showPast: false};
      scope.editing = null;       // copy of a profile while the form is open
      scope.selling = null;       // sell / retire form while it is open
      scope.confirmRemove = false;
      scope.toast = null;
      scope.acquiredOptions = ['Bought new', 'Bought used', 'Built it', 'Gift', 'Won it', 'Other'];
      scope.soldReasons = ['Sold', 'Traded in', 'Scrapped', 'Gave away', 'Retired'];
      scope.wearSpeeds = [{key: 'easy', label: 'Easy'}, {key: 'normal', label: 'Normal'}, {key: 'hard', label: 'Hard'}];

      var lastToastId = null, toastTimer = null, issued = 0, applied = 0, misses = 0;

      // ---- talking to the game -------------------------------------------------
      function api() {
        if (typeof bngApi !== 'undefined' && bngApi) return bngApi;
        if (typeof window !== 'undefined' && window.bngApi) return window.bngApi;
        return null;
      }
      function luaString(v) {
        return '"' + String(v).replace(/[\\"\x00-\x1f]/g, function (c) {
          if (c === '\\') return '\\\\';
          if (c === '"') return '\\"';
          if (c === '\n') return '\\n';
          return ' ';
        }) + '"';
      }
      function toLua(v, depth) {
        if (depth > 3) throw new Error('too deep');
        if (typeof v === 'string') return luaString(v);
        if (typeof v === 'boolean') return v ? 'true' : 'false';
        if (typeof v === 'number') { if (!isFinite(v)) throw new Error('bad number'); return String(v); }
        if (v && typeof v === 'object' && !Array.isArray(v)) {
          return '{' + Object.keys(v).filter(function (k) { return v[k] !== null && v[k] !== undefined; }).map(function (k) {
            if (!/^[A-Za-z][A-Za-z0-9_]*$/.test(k)) throw new Error('bad key');
            return k + '=' + toLua(v[k], depth + 1);
          }).join(',') + '}';
        }
        throw new Error('unsupported');
      }
      function send(payload) {
        var a = api();
        if (!a) { scope.problem = 'Can\'t reach the game. Try reloading the UI (Ctrl+F5 in game).'; return; }
        try { a.engineLua('torqzGarage.uiAction(' + toLua(payload, 0) + ')'); }
        catch (e) { showToast({text: 'That request had invalid data and was not sent.', kind: 'error'}); }
        $timeout(refresh, 120);
      }
      function asList(x) {
        if (Array.isArray(x)) return x;
        if (x && typeof x === 'object') {
          return Object.keys(x).sort(function (a, b) { return Number(a) - Number(b); }).map(function (k) { return x[k]; });
        }
        return [];
      }
      function apply(raw, seq) {
        if (seq < applied) return;
        var data = raw;
        for (var i = 0; i < 2 && typeof data === 'string'; i++) {
          try { data = JSON.parse(data); } catch (e) { scope.problem = 'The garage sent unreadable data. Check the game log for [Torqz].'; scope.loading = false; return; }
        }
        if (!data || typeof data !== 'object') return;
        if (data.error) { scope.problem = data.error; scope.loading = false; return; }
        applied = seq; misses = 0;
        data.vehicles = asList(data.vehicles).map(function (v) {
          v.wear = asList(v.wear); v.service = asList(v.service); v.trips = asList(v.trips);
          v.crashes = asList(v.crashes); v.badges = asList(v.badges); v.stats = v.stats || {}; v.effects = v.effects || {};
          return v;
        });
        if (data.current) data.current.suggestions = asList(data.current.suggestions);
        data.toasts = asList(data.toasts);
        scope.s = data;
        scope.loading = false;
        scope.problem = data.saveOk === false ? (data.problem || 'Saving is turned off.') : null;
        var newest = data.toasts[data.toasts.length - 1];
        if (newest && lastToastId !== null && newest.id !== lastToastId) showToast(newest);
        if (newest) lastToastId = newest.id; else if (lastToastId === null) lastToastId = 0;
        if (scope.selectedId && !scope.car(scope.selectedId)) { scope.selectedId = null; scope.editing = null; }
      }
      function refresh() {
        var a = api();
        if (!a) { scope.loading = false; scope.problem = 'Can\'t reach the game. Try reloading the UI.'; return; }
        var seq = ++issued;
        a.engineLua('torqzGarage.uiState()', function (raw) {
          scope.$evalAsync(function () { apply(raw, seq); });
        });
      }
      function showToast(t) {
        scope.toast = t;
        if (toastTimer) $timeout.cancel(toastTimer);
        toastTimer = $timeout(function () { scope.toast = null; }, 4500);
      }

      // ---- lookups & formatting -------------------------------------------------
      scope.car = function (id) {
        var list = scope.s.vehicles;
        for (var i = 0; i < list.length; i++) if (list[i].id === id) return list[i];
        return null;
      };
      scope.currentCar = function () { return scope.s.current && scope.s.current.recordId ? scope.car(scope.s.current.recordId) : null; };
      scope.km = function () { return scope.s.settings && scope.s.settings.units === 'kmh'; };
      scope.dist = function (m, digits) {
        if (typeof m !== 'number') return '—';
        var v = scope.km() ? m / 1000 : m / 1609.344;
        return v.toFixed(digits === undefined ? 1 : digits) + (scope.km() ? ' km' : ' mi');
      };
      scope.speed = function (ms) {
        if (typeof ms !== 'number') return '—';
        return Math.round(Math.abs(ms) * (scope.km() ? 3.6 : 2.2369));
      };
      scope.speedUnit = function () { return scope.km() ? 'km/h' : 'mph'; };
      scope.time = function (sec) {
        if (typeof sec !== 'number') return '—';
        var h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60);
        return h > 0 ? h + 'h ' + m + 'm' : m + 'm ' + Math.floor(sec % 60) + 's';
      };
      scope.date = function (epoch) {
        if (!epoch) return '—';
        var d = new Date(epoch * 1000);
        return d.toLocaleDateString(undefined, {month: 'short', day: 'numeric', year: 'numeric'});
      };
      scope.healthClass = function (h) { return h > 50 ? 'good' : (h > 20 ? 'warn' : 'bad'); };
      scope.healthText = function (h) { return h > 50 ? 'Good' : (h > 20 ? 'Due soon' : 'Service now'); };
      scope.worst = function (car) {
        var w = 100;
        (car && car.wear || []).forEach(function (p) { if (p.health < w) w = p.health; });
        return w;
      };
      scope.subtitle = function (car) {
        if (!car) return '';
        var p = car.profile || {};
        var bits = [p.year, p.make, p.modelName, p.trim].filter(function (x) { return x; });
        return bits.length ? bits.join(' ') : car.model;
      };
      scope.list = function () {
        var q = (scope.ui.search || '').toLowerCase().trim();
        var out = scope.s.vehicles.filter(function (c) {
          if (c.sold) return false;
          if (!q) return true;
          var p = c.profile || {};
          return [c.name, c.model, p.make, p.modelName, p.plate, p.ownerName, p.color].join(' ').toLowerCase().indexOf(q) >= 0;
        });
        out.sort(function (a, b) {
          if (a.favorite !== b.favorite) return a.favorite ? -1 : 1;
          if (scope.ui.sortBy === 'miles') return b.meters - a.meters;
          if (scope.ui.sortBy === 'name') return a.name.localeCompare(b.name);
          if (scope.ui.sortBy === 'service') return scope.worst(a) - scope.worst(b);
          return b.lastUsedAt - a.lastUsedAt;
        });
        return out;
      };
      scope.pastList = function () {
        return scope.s.vehicles.filter(function (c) { return c.sold; })
          .sort(function (a, b) { return (b.sold.at || 0) - (a.sold.at || 0); });
      };
      scope.owned = function () { return scope.s.vehicles.filter(function (c) { return !c.sold; }); };
      scope.serviceCar = function () {
        var picked = scope.car(scope.ui.serviceId);
        var c = (picked && !picked.sold ? picked : null) || scope.currentCar() || scope.owned()[0] || null;
        if (c && scope.ui.serviceId !== c.id) scope.ui.serviceId = c.id;
        return c;
      };
      scope.dueText = function (p) {
        if (!p || typeof p.dueIn !== 'number') return '';
        if (p.dueIn <= 0) return 'due now';
        var v = scope.km() ? p.dueIn / 1000 : p.dueIn / 1609.344;
        return 'due in ~' + (v < 10 ? v.toFixed(1) : Math.round(v).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')) + (scope.km() ? ' km' : ' mi');
      };
      scope.soldText = function (car) {
        var s = car && car.sold;
        if (!s) return '';
        var bits = [s.reason || 'Sold', scope.date(s.at)];
        if (s.buyer) bits.push('to ' + s.buyer);
        if (s.price) bits.push('for ' + s.price);
        return bits.join(' · ');
      };
      scope.fuel = function () {
        var t = scope.s.current && scope.s.current.telem;
        return t && typeof t.fuel === 'number' ? Math.round(t.fuel * 100) : null;
      };

      // ---- navigation & actions ---------------------------------------------------
      scope.go = function (tab) { scope.tab = tab; scope.confirmRemove = false; scope.editing = null; scope.selling = null; if (tab === 'garage') scope.selectedId = null; };
      scope.toggleMini = function () { scope.mini = !scope.mini; refresh(); };
      scope.open = function (car) { scope.selectedId = car.id; scope.tab = 'garage'; scope.confirmRemove = false; scope.editing = null; scope.selling = null; scope.ui.detailTab = 'overview'; };
      scope.back = function () { scope.selectedId = null; scope.editing = null; scope.selling = null; scope.confirmRemove = false; };
      scope.startSell = function () { scope.confirmRemove = false; scope.selling = {reason: 'Sold', buyer: '', price: ''}; };
      scope.cancelSell = function () { scope.selling = null; };
      scope.sell = function (car) {
        if (!scope.selling) return;
        send({type: 'sell', id: car.id, value: angular.copy(scope.selling)});
        scope.selling = null;
      };
      scope.unsell = function (car) { send({type: 'unsell', id: car.id}); };
      scope.setWearSpeed = function (k) { send({type: 'setting', key: 'wearSpeed', value: k}); };
      scope.add = function () { send({type: 'add'}); };
      scope.connect = function (id) { send({type: 'connect', id: id}); };
      scope.disconnect = function () { send({type: 'disconnect'}); };
      scope.favorite = function (car) { send({type: 'favorite', id: car.id}); };
      scope.spawn = function (car) { if (!car.live) send({type: 'spawn', id: car.id}); };
      scope.setWear = function (on) { send({type: 'setting', key: 'wearAffectsDriving', value: !!on}); };
      scope.money = function (v) { return '$' + Math.round(v || 0).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ','); };
      scope.effectText = function (car) {
        if (!car || !scope.s.settings.wearAffectsDriving) return '';
        var e = car.effects || {}, bits = [];
        if (e.brakes < 0.995) bits.push('brakes ' + Math.round(e.brakes * 100) + '%');
        if (e.tires < 0.995) bits.push('grip ' + Math.round(e.tires * 100) + '%');
        if (e.engine < 0.995) bits.push('power ' + Math.round(e.engine * 100) + '%');
        return bits.length ? 'Wear is affecting this car: ' + bits.join(', ') + '. Service it to fix.' : '';
      };
      scope.service = function (car, what) { send({type: 'service', id: car.id, value: what}); };
      scope.goService = function (car) { scope.ui.serviceId = car.id; scope.go('service'); };
      scope.edit = function (car) {
        var p = car.profile || {};
        scope.selectedId = car.id;
        scope.tab = 'garage';
        scope.editing = {
          nickname: p.nickname || '', year: p.year || '', make: p.make || '', modelName: p.modelName || '',
          trim: p.trim || '', color: p.color || '', plate: p.plate || '', purchaseDate: p.purchaseDate || '',
          purchasePrice: p.purchasePrice || '', ownerName: p.ownerName || scope.s.settings.ownerName || '',
          acquired: p.acquired || 'Bought new', notes: car.notes || ''
        };
      };
      scope.saveProfile = function () {
        if (!scope.editing || !scope.selectedId) return;
        send({type: 'profile', id: scope.selectedId, value: angular.copy(scope.editing)});
        scope.editing = null;
      };
      scope.cancelEdit = function () { scope.editing = null; };
      scope.remove = function (car) {
        if (!scope.confirmRemove) { scope.confirmRemove = true; return; }
        send({type: 'remove', id: car.id});
        scope.confirmRemove = false; scope.selectedId = null;
      };
      scope.setUnits = function (u) { send({type: 'setting', key: 'units', value: u}); };
      scope.keep = function () { scope.confirmRemove = false; };
      scope.saveOwner = function () { send({type: 'setting', key: 'ownerName', value: scope.ui.ownerDraft || ''}); };
      scope.$watch('tab', function (t) { if (t === 'settings') scope.ui.ownerDraft = scope.s.settings.ownerName || ''; });

      // ---- lifecycle ---------------------------------------------------------------
      var ticks = 0;
      var poll = $interval(function () {
        ticks++;
        if (scope.mini && ticks % 2) return; // mini mode: refresh every 2 s
        refresh();
        if (++misses > 5 && scope.loading) { scope.loading = false; scope.problem = 'No answer from Torqz Garage. Make sure the mod is turned on in the Mod Manager, then check the game log for [Torqz].'; }
      }, 1000);
      scope.$on('$destroy', function () { $interval.cancel(poll); if (toastTimer) $timeout.cancel(toastTimer); });
      refresh();
    }
  };
}]);
