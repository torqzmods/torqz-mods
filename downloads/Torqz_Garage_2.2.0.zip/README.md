# Torqz Garage 2.2 | Torqz Mods

Own your cars in BeamNG.drive. Every car you add keeps its miles, driving time,
condition, service history and a profile you fill in yourself.

## What it does
- **Add to garage**: get in any car and press *Add to garage* in the Torqz Garage app.
- **Recognizes your cars**: spawn a car you own and it reconnects by itself
  ("Welcome back, Big Blue"). If you changed its parts, pick it from *Is this one of yours?* once.
  AI traffic never takes over your records.
- **Mileage & driving time** for every owned car, plus the current trip.
- **Wear & service**: engine oil, tires, brakes and air filter wear as you drive.
  Hard braking, fast launches and high revs wear them faster. Service one part or everything;
  each service is logged. 
- **Car profile & owner info**: year, make, model, trim, color, plate, purchase date and price,
  owner name, nickname, how you got it, and notes.
- **Spawn from garage**: every car's parts, tuning and paint are saved. Press *Spawn* to bring it out with its plate.
- **Crash & damage history**: crashes are logged with an estimated repair cost; repairs are logged too.
- **Trip log & milestones**: every drive is saved, and cars earn 19 badges like *First mile*, *Road trip*,
  *Clean streak* and *Ton up*.
- **Sell or retire**: move a car to *Past cars* with its whole history, and bring it back any time.
- **Wear speed**: Easy, Normal or Hard in Settings.
- **Due in**: the Service tab guesses how far until each part needs a service.
- **Garage totals**: total cars, distance, seat time, drives, crashes and badges across your garage.
- **Wear affects driving** (optional): worn brakes, bald tires, old oil and a dirty filter make the car brake, grip
  and pull worse until you service it. Turn it off in Settings.
- **Mini mode**: shrink the app to a small pill showing your car, its miles and four condition lights.

## Install
Put the mod in your BeamNG user folder's `mods` folder (launcher → Manage User Folder → Open in Explorer).
Then in Freeroam open the UI Apps menu and add **Torqz Garage** if it isn't already on screen.

## Your save
`<BeamNG user folder>/settings/torqz_garage/garage.json` (with `garage.backup.json` next to it).
Removing the mod doesn't delete your garage.

## Files
- `scripts/torqzGarage/modScript.lua`: starts the mod
- `lua/ge/extensions/torqzGarage.lua`: the garage itself (saving, recognizing cars, wear, service, profiles)
- `lua/vehicle/extensions/auto/torqzGarageVehicle.lua`: measures driving in the car you're in
- `ui/modules/apps/TorqzGarage/`: the in-game app

Problems? Look for lines starting with `[Torqz]` in `beamng.log`.
